---
name: Feature
about: Feature request or proposal
---

### I have idea for a new feature for jQuery Terminal

<!-- add your idea here -->
